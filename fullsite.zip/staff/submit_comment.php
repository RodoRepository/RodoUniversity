<?php
session_start();
$server="mysql.cms.gre.ac.uk";
$dbName="mdb_an6827t";
$user="an6827t";
$pass="an6827t";


$conn = new mysqli($server, $user, $pass, $dbName);


if ($conn->connect_error) {
	die ("Connection error"  . $conn->connect_error); 
}

//echo "connection success"; 

// Grab the values from post 



$pIDl=$_SESSION['pIDD'];
$userID=$_SESSION['UserID'];
$comment=$_POST['comment'];


$sql = "INSERT INTO Comments (PostId, UserId, Text) VALUES
('$pIDl', '$userID', '$comment');";
$red = "view_single_idea.php?postID=" . $pIDl;

if ($conn->query($sql) === TRUE) {
   
	  echo "Comment Submitted.  Please wait...";
								header( "refresh:2;url=" . $red );
} else {
    echo "Unable to add comment!  Please wait... ";
}


			

								
			$sql2 = "SELECT u.Email, u.FirstName from Users u INNER JOIN Ideas i ON i.UserId = u.UserID AND i.PostId=" . $pID1 . " AND i.UserID=" . $userID;

			$res = $conn->query($sql2);
										
			while($row1 = $res->fetch_assoc()) {
				echo $email = $row1['Email'];
				echo $fName = $row1['FirstName'];
				echo $pID1 = $row1['PostId'];
										
				}
								echo "got here";	
				
			$conn->close();
							
							$to = $email;
							$subject = "New Comment on your idea!";

							$message = "
							<html>
							<head>
							<title>New Comment Received</title>
							</head>
							<body>
							<p>Hello " . $fName . "</p>

							<p> A New comment has been submitted for one of your ideas!</p>
							<p><a href=\"https://stuweb.cms.gre.ac.uk/~lj4136j/staff/view_single_idea.php?postID=" . $pID1 . "\"
						>Click here to view the current ideas</a></p>
							<br><p> All the best, Rodo University!</p></br>

							</body>
							</html>
							";

							// Always set content-type when sending HTML email
							$headers = "MIME-Version: 1.0" . "\r\n";
							$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

							// More headers
							$headers .= 'From: <webmaster@rodouniversity.com>' . "\r\n";
							$headers .= 'Cc: ' . "\r\n";

							mail($to,$subject,$message,$headers);
							
							  echo "Comment Submitted.  Please wait...";
								header( "refresh:2;url=" . $red );
													

?>
