<?php
session_start();
session_unset();
session_destroy();
echo "You have been logged out.  Please wait...";
header( "refresh:1;url=../index.php");

?>