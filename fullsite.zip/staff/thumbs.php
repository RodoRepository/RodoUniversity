<?php
session_start();
$server="mysql.cms.gre.ac.uk";
$dbName="mdb_an6827t";
$user="an6827t";
$pass="an6827t";


$conn = new mysqli($server, $user, $pass, $dbName);


if ($conn->connect_error) {
	die ("Connection error"  . $conn->connect_error); 
}




$userID=$_SESSION['UserID'];
$upordown=$_GET['thumbs'];
$postID=$_GET['postID'];



// Check if voted before
$sql = "SELECT * FROM Votes WHERE postID=" . $postID . " AND UserId=" . $userID;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	echo "You can only vote one time per post!";
	header( "refresh:2;url=view_single_idea.php?postID=" . $postID );
}
else{

$sql = "INSERT INTO Votes (UserId, vote, postID) VALUES
('$userID', '$upordown', '$postID');";

if ($conn->query($sql) === TRUE) {
    echo "Vote Submitted.  Please wait...";
	header( "refresh:2;url=view_single_idea.php?postID=" . $postID );
} else {
    echo "Error posting vote!  Please wait...!";
	header( "refresh:2;url=view_single_idea.php?postID=" . $postID );
}
}
$conn->close();
?>
