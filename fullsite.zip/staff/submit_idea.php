<?php
session_start();
$server="mysql.cms.gre.ac.uk";
$dbName="mdb_an6827t";
$user="an6827t";
$pass="an6827t";


$conn = new mysqli($server, $user, $pass, $dbName);


if ($conn->connect_error) {
	die ("Connection error"  . $conn->connect_error); 
}




$userID=$_SESSION['UserID'];
$idea=$_POST['idea'];
$title=$_POST['title'];


$sql = "INSERT INTO Ideas (UserId, Title, Body) VALUES
('$userID', '$title', '$idea');";

if ($conn->query($sql) === TRUE) {
    echo "Idea Submitted.  Please wait...";
	header( "refresh:2;url=view_all_ideas.php" );
} else {
    echo "Error posting idea!  Please wait...!";
	header( "refresh:2;url=view_all_ideas.php");
}

$conn->close();

// let the admin know a new idea has been added


$to = "lj4136j@greenwich.ac.uk, as5367v@greenwich.ac.uk, sr9376d@greenwich.ac.uk";
$subject = "New Idea from Rodo University";

$message = "
<html>
<head>
<title>New Idea Submitted</title>
</head>
<body>
<p>Hello!</p>

<p> A New idea has been submitted by user <b>" . $userID . "</b>, titled <b>" . $title . "</b></p>
<p><a href=\"https://stuweb.cms.gre.ac.uk/~lj4136j/staff/view_all_ideas.php\">Click here to view the current ideas</a></p>
<br><p> All the best, Rodo University!</p></br>

</body>
</html>
";

// set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <webmaster@rodouniversity.com>' . "\r\n";
$headers .= 'Cc: ' . "\r\n";

mail($to,$subject,$message,$headers);
?>

