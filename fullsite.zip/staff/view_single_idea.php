<?php
session_start(); 
if ($_SESSION['status'] !== 1)
{
header( "refresh:1;url=../index.php") ;
}					
 ?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/assets/images/favicon.png">
    <title>Staff Dashboard</title>
    <!-- Custom CSS -->
    <link href="../assets/assets/libs/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet" />
    <link href="../assets/assets/extra-libs/calendar/calendar.css" rel="stylesheet" />
    <link href="../assets/dist/css/style.min.css" rel="stylesheet">
	
	<!-- Glypicons bootstrap rel -->
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="index.html">
                        
                        <!--End Logo icon -->
                         <!-- Logo text -->
                        <span class="logo-text">
                             <!-- dark Logo text -->
                             <h2>Staff Dashboard</h2>
                            
                        </span>
                        <!-- Logo icon -->
                        <!-- <b class="logo-icon"> -->
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <!-- <img src="assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->
                            
                        <!-- </b> -->
                        <!--End Logo icon -->
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
					 <li class="sidebar-item"> <p>
					<a href="logout.php" class="btn btn-info btn-lg">
					<span class="glyphicon glyphicon-log-out"></span> Log out
					</a>
					</p> </li>
               
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="staff_dashboard.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="user_profile.php" aria-expanded="false"><i class="mdi mdi-account"></i><span class="hide-menu">User Profile</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="view_all_ideas.php" aria-expanded="false"><i class="mdi mdi-chart-bubble"></i><span class="hide-menu">View All Ideas</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="submit_idea_form.php" aria-expanded="false"><i class="mdi mdi-receipt"></i><span class="hide-menu">Submit Idea Form</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">User Idea
					</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Ideas</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12 mb-4">
									<?php
									$server="mysql.cms.gre.ac.uk";
									$dbName="mdb_an6827t";
									$user="an6827t";
									$pass="an6827t";


									$conn = new mysqli($server, $user, $pass, $dbName);

									
									if ($conn->connect_error) {
										die ("Connection error"  . $conn->connect_error); 
									}
									  
									  $pID = $_GET['postID'];
									  $_SESSION['pIDD'] = $pID;
										$sql="SELECT  Title, Body FROM Ideas WHERE PostID=" . $_GET['postID'];

										$result = $conn->query($sql);
										
										 while($row = $result->fetch_assoc()) {
												$pTitle = $row['Title'];
												$pBody = $row['Body'];
												
												echo "<h2>" . $pTitle . "</h2>";
										echo "<p>" . $pBody . "</p>";
										
										
										 }
									
							$conn->close();
							?>
								
                                   

                                      
                                        <br>
                                        <h4>Attachments</h4>
                                        <div class="row">
                                            <div class="col-md-2 mb-3"><img src="../assets/assets/images/big/img1.jpg" class="img-fluid"></div>
                                            <div class="col-md-2 mb-3"><img src="../assets/assets/images/big/img2.jpg" class="img-fluid"></div>
                                            <div class="col-md-2 mb-3"><img src="../assets/assets/images/big/img3.jpg" class="img-fluid"></div>
                                        </div>
                                        <br>
                                        <h4>Give your views?</h4>
                                        <div class="row">
                                            <div class="col-md-12">
											<?php
											$upURL="thumbs.php?postID=" . $_SESSION['pIDD'] . "&thumbs=1";
											$downURL ="thumbs.php?postID=" . $_SESSION['pIDD'] . "&thumbs=0";
											
											
											
											// count votes
											$server="mysql.cms.gre.ac.uk";
											$dbName="mdb_an6827t";
											$user="an6827t";
											$pass="an6827t";


											$conn = new mysqli($server, $user, $pass, $dbName);


											if ($conn->connect_error) {
												die ("Connection error"  . $conn->connect_error); 
											}



											// Grab the values from post 

											$username=$_POST["login-username"];
											$password= md5($_POST["login-password"]);   // encrypt MD5


											$sql="SELECT * FROM Votes WHERE postID='$pID' AND vote=1";

											$result = $conn->query($sql);

											$voteup = $result->num_rows ;
											$sql="SELECT * FROM Votes WHERE postID='$pID' AND vote=0";
											$result = $conn->query($sql);
											$votedown = $result->num_rows ;
											$conn->close();
											
											echo $voteup; ?> &nbsp 
											
											<?php
											echo "<a href=\"" . $upURL . "\" style=\"font-size: 20px;\"><i class=\"mdi mdi-thumb-up\"></i></a>"; ?> &nbsp &nbsp
                                           <?php 
										   echo $votedown ?> &nbsp
										   
										   <?php echo "<a href=\""  . $downURL . "\" style=\"font-size: 20px;\"><i class=\"mdi mdi-thumb-down\"></i></a>";
                                                ?>
                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <h4>Ratings</h4>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <a href="#" style="font-size: 20px;color: #ff9529;"><i class="mdi mdi-star"></i></a>
                                                <a href="#" style="font-size: 20px;color: #ff9529;"><i class="mdi mdi-star"></i></a>
                                                <a href="#" style="font-size: 20px;color: #ff9529;"><i class="mdi mdi-star"></i></a>
                                                <a href="#" style="font-size: 20px;color: #ff9529;"><i class="mdi mdi-star"></i></a>
                                                <a href="#" style="font-size: 20px;color: #ff9529;"><i class="mdi mdi-star-half"></i></a>
                                            </div>
                                        </div>
                                        <br>
                                        <br>
                                        <h4>Comments</h4>
										<?php
									$server="mysql.cms.gre.ac.uk";
									$dbName="mdb_an6827t";
									$user="an6827t";
									$pass="an6827t";


									$conn = new mysqli($server, $user, $pass, $dbName);

									
									if ($conn->connect_error) {
										die ("Connection error"  . $conn->connect_error); 
									}
									$pID = $_GET['postID'];
									$sql = "SELECT u.FirstName, u.LastName, c.Text, c.Date FROM Users u INNER JOIN Comments c ON c.UserId = u.UserId AND c.PostId=" . $pID;

										$result = $conn->query($sql);
										
										 while($row = $result->fetch_assoc()) {
												$pText = $row['Text'];
												$pName = $row['FirstName'] . " " . $row['LastName'];
												$pDate = $row['Date'];
											echo "<div class=\"d-flex flex-row comment-row mt-3\">
                                            <div class=\"p-2\"><img src=\"../assets/assets/images/users/1.jpg\" alt=\"user\" width=\"50\" class=\"rounded-circle\"></div>
                                            <div class=\"comment-text w-100\">
                                                <h6 class=\"font-medium\">" ;
												echo $pName; 
												echo "</h6> <span class=\"m-b-15 d-block\">"; 
												echo $pText; 
												echo "</span>
                                                <div class=\"comment-footer\">
                                                    <span class=\"text-muted\">" . $pDate . "</span> 
                                                </div>
                                            </div>
											</div>";
										
										
										 }
									
							$conn->close();
							?>
								 
                                        

                                     
                                       
                                        <br>
                                        <br>
										<form role="form" action="submit_comment.php" method="post" id="form1">
                                        <h4>Write Comment</h4>
                                        <div class="form-group row">
                                            <label for="name" class="col-sm-2 control-label col-form-label">Name</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="name" placeholder="
												<?php 
												session_start(); 
												echo $_SESSION['fname'] . " " . $_SESSION['lname'] . "\" disabled>"; 
												?>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="email" class="col-sm-2 control-label col-form-label">Email</label>
                                            <div class="col-sm-8">
                                                <input type="email" class="form-control" id="email" placeholder="
												<?php 
												session_start();
												echo $_SESSION['user'] . "\" disabled>"; ?> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="cono1" class="col-sm-2 control-label col-form-label">Message</label>
                                            <div class="col-sm-8">
                                                <textarea class="form-control" placeholder="Message" rows="7" name="comment" id="comment"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <button type="submit" form="form1" class="btn btn-primary" value="Submit">Submit Comment</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved.</a>.
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/dist/js/jquery.ui.touch-punch-improved.js"></script>
    <script src="../assets/dist/js/jquery-ui.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../assets/assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../assets/assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effeassets/cts -->
    <script src="../assets/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../assets/dist/js/sidebarmenu.js"></script>
    <!--Custom Ja../vaScript -->
    <script src="../assets/dist/js/custom.min.js"></script>
    <!-- this page js -->
    <script src="../assets/assets/libs/moment/min/moment.min.js"></script>
    <script src="../assets/assets/libs/fullcalendar/dist/fullcalendar.min.js"></script>
    <script src="../assets/dist/js/pages/calendar/cal-init.js"></script>

</body>

</html>